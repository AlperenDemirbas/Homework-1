import java.util.Stack;

public class Problem3 {

    static Stack<Integer> stack = new Stack<Integer>();

    public static void AddToQueue(int number){
        stack.push(number);                                  // adding elements to stack
    }

    public static int QueueUp(){
        int value = stack.get(0);                          // assigning the top element of the stack to a variable
        stack.remove(0);                             // deleting the top element of the stack
        return value;                                       // we returned the variable and removed the first element
}
