public class Problem1{

    public static int ticketWaittimeCalculate(int[] TicketNumbers, int k){
        int TotalWaitTime = 0;                                
        int totalTour = TicketNumbers[k];                           // total number of laps
        for (int i = 0; i < totalTour; i++) {                       
            for (int j = 0; j < TicketNumbers.length; j++) {        
                if(TicketNumbers[j] > 0){                           
                    TicketNumbers[j]--;                             
                    TotalWaitTime++;                          
                    if(j == k && TicketNumbers[j] == 0){            
                        return TotalWaitTime;                 // return total wait time
                    }
                }
            }
        }
        return 0;
    }

}