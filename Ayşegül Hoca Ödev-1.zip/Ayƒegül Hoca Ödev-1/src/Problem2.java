import java.util.Stack;

public class Problem2 {

    public static Stack<Integer> stackSort(Stack<Integer> stack){
        Stack<Integer> newStack = new Stack<Integer>();                    // create new stack
        while(!stack.isEmpty()){                                            // will loop until stack is empty
            int lastElement = stack.pop();                                    // assign last element in stack to lastElement variable
            while(!newStack.isEmpty() && newStack.peek() > lastElement){    // if the new stack is not empty and the top element of the new stack is greater than the temp variable
                stack.push(newStack.pop());                                // we extract an element from the new stack and assign it to the stack
            }
            newStack.push(lastElement);                                      // we add element to new stack
        }
        return newStack;                                                   // we return the new stack
    }

}