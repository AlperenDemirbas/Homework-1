import java.util.Stack;

public class Main {

    public static void main(String[] args) {

        int[] TicketNumbers = {2, 3, 9};                                                // array to hold ticket counts
        System.out.println(Problem1.ticketWaittimeCalculate(TicketNumbers, 1));    

       

        Stack<Integer> stack = new Stack<Integer>();                                    
        stack.push(9);                                                              
        stack.push(3);
        stack.push(2);
        stack.push(7);
        stack.push(6);

        System.out.println(Problem2.stackSort(stack));                                    // Stack is sent to stackSort method and returned value is printed
        

        Problem3.AddToQueue(1);                                 
        Problem3.AddToQueue(2);
        Problem3.AddToQueue(3);
        Problem3.AddToQueue(4);
        Problem3.AddToQueue(5);
        Problem3.AddToQueue(6);
        Problem3.AddToQueue(7);
        Problem3.AddToQueue(8);
        Problem3.AddToQueue(9);
        Problem3.AddToQueue(10);
        System.out.println(Problem3.stack);                         
        System.out.println(Problem3.QueueUp());              /* The initial state of the stack is printed and the top element of the queue is removed with the QueueUp method */
        System.out.println(Problem3.QueueUp());
        System.out.println(Problem3.QueueUp());
        System.out.println(Problem3.QueueUp());
        System.out.println(Problem3.stack);                          // the final version of the stack is printed

    }
}
//Alperen Demirbaş 211450030